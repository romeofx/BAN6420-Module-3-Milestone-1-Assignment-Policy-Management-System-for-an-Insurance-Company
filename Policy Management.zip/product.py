
class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price

    def create_product(self):
        print(f"Product {self.name} created with ID {self.product_id} and price {self.price}")

    def update_product(self, name=None, price=None):
        if name:
            self.name = name
        if price:
            self.price = price
        print(f"Product {self.product_id} updated to Name: {self.name}, Price: {self.price}")

    def remove_product(self):
        print(f"Product {self.name} with ID {self.product_id} removed.")
