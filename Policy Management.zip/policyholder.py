
class Policyholder:
    def __init__(self, name, policy_id, status='active'):
        self.name = name
        self.policy_id = policy_id
        self.status = status
        self.product_paid = False

    def register_policyholder(self):
        self.status = 'active'
        print(f"Policyholder {self.name} registered successfully.")

    def suspend_policyholder(self):
        self.status = 'suspended'
        print(f"Policyholder {self.name} suspended.")

    def reactivate_policyholder(self):
        self.status = 'active'
        print(f"Policyholder {self.name} reactivated.")

    def display_details(self):
        print(f"Policyholder Name: {self.name}, Policy ID: {self.policy_id}, Status: {self.status}, Product Paid: {self.product_paid}")

    def pay_for_product(self):
        self.product_paid = True
        print(f"{self.name} has paid for the product.")
