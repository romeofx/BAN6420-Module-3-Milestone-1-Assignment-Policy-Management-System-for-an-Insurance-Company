
class Payment:
    def __init__(self, payment_id, amount, policyholder):
        self.payment_id = payment_id
        self.amount = amount
        self.policyholder = policyholder

    def process_payment(self):
        print(f"Processing payment of {self.amount} for {self.policyholder.name}.")
        self.policyholder.pay_for_product()

    def send_reminder(self):
        print(f"Reminder: Payment is due for {self.policyholder.name}.")

    def apply_penalty(self):
        penalty = 50  # flat penalty for this example
        print(f"Penalty of {penalty} applied to {self.policyholder.name}.")
